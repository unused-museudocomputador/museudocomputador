/**
 * Main JS file
 */

require(['delta'], function () {

});
