/**
 * Main JS file
 */
// require.config({

//   paths: {
//     jquery: 'jquery',
//     turbolinks: 'turbolinks',
//     jquery_ujs: 'jquery_ujs'
//   }

// });

require(['delta'], function () {

});
